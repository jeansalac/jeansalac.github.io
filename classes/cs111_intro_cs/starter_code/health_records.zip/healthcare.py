'''
healthcare.py

Adapted from materials by Chloe Simanek '26 and Ava Amthauer '26

'''
from datetime import datetime
import matplotlib.pyplot as plt

'''
Step 1: Retrieving Data
'''

def retrieve_data(filename):
    # Lists to store each column
    names = []
    ages = []
    # TODO: Initialize lists to store the remaining fields

    # Open the file and read the data
    with open(filename) as file:
        next(file)  # Skip the header line
        for line in file: 
            fields = line.strip().split(",") 
            names.append(fields[0])
            ages.append(int(fields[1]))
            # TODO: Continue appending to the lists below

'''
Step 2: Accessing Data
'''
# TODO: Implement the following functions below
def access_patient():
    return

def index_field():
    return

'''
Step 3: Analyzing Data
'''
# TODO: Implement the following functions below
def get_age_distribution():
    return

def get_gender_distribution():
    return

def get_hospital_distribution():
    return


def main() :
    filename = "healthcare_data.csv"

    # TODO: Test your Step 1-3 functions here

    # TODO: Implement your Step 4 plots herel


if __name__=='__main__':
    main()