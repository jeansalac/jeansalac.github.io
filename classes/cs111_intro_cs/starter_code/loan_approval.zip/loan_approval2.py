'''
Adapted from materials by Ryan Woohyeok Choi '26
'''

'''
EXAMPLE FUNCTIONS:
Name input function
The while loop prevents the program to continue until it has received a valid input.
'''
def get_name() :
    while True:
        # You should consider the type of input received. In this case 'name' would be string.
        name = input("What is your name? \n>")
        # Check if the applicant has entered a valid input
        # name cannot be an empty string and must be alphabetical
        if name == "" or not name.isalpha():
            print("Enter a valid name.")
        else:
            break
    return name
  
'''    
Age input function
Employs same strategy as function above.
'''
def get_age() :
    while True:
        # You should consider the type of input received. In this case 'age' should be an int
        # Since any variables received using the input() function is string by default, 
        age = input("What is your age? \n>")
        # Check if the applicant has entered a valid input
        # age must be a digit
        if not age.isdigit():
            print("Enter a valid age.")
        else:
            # you must use the int() function to convert the input to an int type
            age = int(age)
            break
    return age

'''
Biological sex input function
'''
def get_sex() :
    while True:
        sex = input("What is your sex? 'M' or 'F'\n>")
        if sex not in ["M", "F"]:
            print("Enter a valid sex.")
        else:
            break
    return sex

'''
Step A
Employment input - Ask if the applicant is employed or not.
'''
def get_employment() :
    # TODO: PUT YOUR CODE HERE
    return 

'''
Step B
Ask for the applicant's contact number and home address.
'''
def get_address() :
    # TODO: PUT YOUR CODE HERE
    return

def get_phone() :
    # TODO: PUT YOUR CODE HERE
    return 

'''
Step C
Contacts and address of the 3 people to "refer" to if the applicant fails to pay the loan
'''
def get_referrals() :
    # TODO: PUT YOUR CODE HERE
    return 

'''
Step D
Ask a list of binary (yes/no) questions asking if the applicant consents to the terms and conditions of the loan
'''
def ask_questions() :
    # TODO: PUT YOUR CODE HERE
    return

'''
Step E
Loan Approval Stage. Your task is to utilize the data inputted from applicant so far and:
(1) add two conditions that would approve the loan 
(2) add two conditions that would deny the loan
You will need to decide the parameters that the function will need based on the conditions
'''
def approval() : 
    # TODO: PUT YOUR CODE HERE
    return "Loan Denied. Sorry."


'''
A main function to help run each of the helper functions.
'''
def main() :
    print("Loan Approval System 1")
    name = get_name()
    age = get_age()
    sex = get_sex()
    employed = get_employment()
    address = get_address()
    phone = get_phone()
    references = get_referrals()
    answers = ask_questions()

    # TODO: Put a print statement for approval decision here

if __name__=='__main__':
    main()