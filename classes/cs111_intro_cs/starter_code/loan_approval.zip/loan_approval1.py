'''
Adapted from materials by Ryan Woohyeok Choi '26
'''

'''
Example: Salary
while loop is used to prevent the program from continuing until a valid input has been inputted from the user
conditionals should be used to check the validity of user input
'''
def get_salary(salary) :
# Based on the salary inputted, points will be added to the corresponding index of the score array 
    if salary >= 5000:
        return 40
    elif salary >= 3000:
        return 25
    elif salary >= 1500:
        return 10


def user_input_salary() :
    while True:
        try:
            salary = int(input("Enter your monthly salary in USD: "))
            if salary <= 0:
                print("Salary should be greater than zero.")
            else:
                break
        except:
            print("Enter a valid salary number.")
        
    return get_salary(salary)

'''
Step A
Monthly income - Process applicant input for any additional monthly income 
'''
def get_monthly_income(income) :
    # TODO: PUT YOUR CODE HERE
     return 

def user_input_income() :
    # TODO: PUT YOUR CODE HERE
    return 

'''
Step B 
Pre-Existing Loans / Debts - Process applicant input for any pre-existing loans or depts
'''
def get_existing_debt(debts) :
    # TODO: PUT YOUR CODE HERE
    return 

def user_input_debt() :
    # TODO: PUT YOUR CODE HERE
    return 

'''
Step C
Pre-Existing Assets - Process applicant input for any pre-existing assets
'''
def get_assets(assets) :
    # TODO: PUT YOUR CODE HERE
    return 

def user_input_assets() :
    # TODO: PUT YOUR CODE HERE
    return 

'''
Step D
Loan Approval Stage - Evaluate the total score & approve/deny the loan
'''
def approval():
    # TODO: PUT YOUR CODE HERE
    return

def main() :
    print("Loan Approval System - Points Based Example")
    scores = []
    scores.append(user_input_salary())
    scores.append(user_input_income())
    scores.append(user_input_debt())
    scores.append(user_input_assets())
    
    # TODO: Put a print statement for approval decision here

if __name__=='__main__':
    main()