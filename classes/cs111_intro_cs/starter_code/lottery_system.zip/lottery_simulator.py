from CommunityMember import *
import random

'''
Step 3: Lottery Helper Functions
'''
# TODO: Implement the following functions below
def winning_lot_number():
    return
    
def matching_numbers():
    return

def calculate_winnings():
    return

def choose_who_plays():
    return

def choose_scholarship_winner():
    return

'''
Step 5: Simulate Multi-Year Lottery Outcomes
'''
# TODO: Implement the following function below
def simulate_year():
    return

# TODO: Implement multi-year simulation
def main():
   # Generate 30 community members, where the first 15 are poorly paid and the last 15 are well-paid
   community = []

   for i in range(30):
       if i < 15:
           community_member = PoorlyPaid()
           community.append(community_member)
       else:
           community_member = WellPaid()
           community.append(community_member)

if __name__=='__main__':
    main()