import random
'''
Step 1: Community Member Class
'''
# TODO: Implement the following class below
class CommunityMember():
    pass # Delete once you have a draft implementation


'''
Step 2: Well-Paid & Poorly-Paid Classes
'''
# TODO: Implement the following classes below
class WellPaid(CommunityMember):
    pass # Delete once you have a draft implementation


class PoorlyPaid(CommunityMember):
    pass # Delete once you have a draft implementation

