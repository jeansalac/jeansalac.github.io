from lottery_simulator import *
import unittest

'''
Step 4: Test Matching Numbers & Calculate Winnings
'''
# TODO: Implement the following tests below
class TestLotteryMethods(unittest.TestCase):

    def test_matching_numbers_standard(self):
        pass # Delete once you have a draft implementation

    def test_matching_numbers_edge(self):
        pass # Delete once you have a draft implementation

    def test_calculate_winnings_standard(self):
        pass # Delete once you have a draft implementation

    def test_calculate_winnings_edge(self):
        pass # Delete once you have a draft implementation



if __name__ == '__main__':
    unittest.main()