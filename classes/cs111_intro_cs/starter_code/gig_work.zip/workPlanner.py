import workInfo as wi 
'''
Description: Program for delivery drivers to calculate their expected weekly income. 
Inspired by the "Work Planner" from the paper "Stakeholder-Centered AI Design: Co-Designing
Worker Tools with Gig Workers through Data Probes".
Based on materials by Ava Amthauer '26, Jamal Omosun '26, & Chloe Simanek '26
'''

'''
Step 1: Defining & Assigning Variables
Define variables for base pay, location, days and more. 
It is best practice to name the variables after what exactly they are representing.
'''
# TODO: Fixed variables go here
# ie: pay = 7.25 

# TODO: Driver-determined variables go here 
# ie: cost_of_fuel = 2.95


'''
Step 2: Calculations
Use operators to estimate weekly income.
wi.checkList is a function that will calculate some multipliers for you.
You do not have to worry about what exactly is going on behind the scenes,
you will learn more about it later in the class.
'''
# Neighborhood and day multipliers. 
# Make sure you have defined variables for neighborhoods and days in Step 1!
neighborhood_multiplier = wi.check_list(neighborhoods)
day_multiplier = wi.check_list(days)

# TODO: Your calculations go here


# TODO: Once you verify that your calculations are correct, implement the functions below.
def calculate_revenue(base_pay, num_jobs_per_hr, hours, day_multiplier, neighborhood_multiplier):
    pass # Delete or comment out this "pass" line once you have an initial implementation of this function


def calculate_expenses(miles_traveled, fuel_efficiency, cost_of_fuel):
    pass # Delete or comment out this "pass" line once you have an initial implementation of this function


def calculate_income(revenue, expenses):
    pass # Delete or comment out this "pass" line once you have an initial implementation of this function


'''
Step 3: Tying it Together: User Input
Allow the driver to enter their preferences and see their estimated weekly income. 
You can comment out all the hard-coded variables that you used beforehand.
You can do this in VS code by using either Ctrl + / or Cmd + /.
'''

def main():
    pass # Delete or comment out this "pass" line once you have an initial implementation of user input
    
    # TODO: Your code for user interaction goes here 
    
if __name__=="__main__":
    main()