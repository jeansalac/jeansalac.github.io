"""
This is a special kind of comment called "docstring", enclosed with three quotation marks.
Docstrings provide a convenient way to document Python functions & to generate multi-line comments.

shopping_simulator.py

Adapted from materials by Jamal Omosun '26 and Chloe Simanek '26

Description: This program includes several functions that are used in an
online shopping simulator. The functions handle product offers, payment plans,
discounts and purchases. Use python3 run_simulator.py to run the full simulation.
"""

import random
import csv
import sys

# ! DO NOT MODIFY THIS FUNCTION READ_ITEMS() !
def read_items(filename):
    """Reads product information from a CSV file.

    Args:
        filename (str): Path to CSV file.
    
    Returns:
        tuple: Three lists containing product names, categories, and prices. 
    """
    products = []
    categories = []
    prices = []
    try:
        with open(filename, newline='') as fh:
            reader = csv.reader(fh)
            headers = next(reader, None)
            for row in reader:
                if len(row) < 3:
                    continue
                categories.append(row[0].strip())
                products.append(row[1].strip())
                try:
                    prices.append(float(row[2]))
                except ValueError:
                    prices.append(0.0)
    except FileNotFoundError:
        print(f"Could not find {filename}. Exiting.")
        sys.exit(1)
    return products, categories, prices

def apply_purchase(balance, total):
    """Subtract cost from balance.

    Args:
        balance: The current balance.
        cost: Cost of a purchase.

    Returns:
        new_balance: The updated balance. 
    """

    # TODO: Implement apply_purchase
    pass

def offer_product(products, categories, prices):
    """Offer a random product from the available products. 

    Args:
        products (list): Product names.
        categories (list): Product categories.
        prices (list): Product prices.

    Returns:
        dict: A dictionary with keys "name", "category", and "price". 
    """

    # TODO: Implement offer_product
    pass

def create_payment_plan(payment_plans, product_price):
    """Create and add a new payment plan to the list.

    The plan includes a 10% surcharge on the product price and divides 
    the total cost into three equal payments.

    Args:
        payment_plans (list of dict): Existing payment plans. 
            Each plan should contain:
                - 'num_payments': Number of payments.
                - 'payment_amount': Dollar amount per payment.
        product_price: Price of the product to create a plan for.

    Returns:
        payment_plans (list of dict): Updated list of payment plans,
            including the new plan.
    """
    # TODO: Implement create_payment_plan
    pass

def apply_payment_plans(balance, payment_plans):
    """Apply all active payment plans to the shoppers's balance.

    For each active payment plan, meaning there are still payments
    remaining (num_payments > 0). Deduct one payment from the balance and 
    decrement the number of payments. Completed plans (num_payments = 0)
    are removed.

    Args:
        balance: Shopper's current balance.
        payment_plans (list of dict): Active payment plans.
            Each plan should contain:
                - 'num_payments': Number of payments.
                - 'payment_amount': Dollar amount per payment.

    Returns:
        tuple:
            balance: Updated balance after applying all payments.
            updated_plans (list[dict]): Updated list of active payment plans
                with decremented 'num_payments' and completed plans removed.
    """
    # TODO: Implement apply_payment_plans
    pass

def offer_discount(price):
    """Randomly apply a 5-15% discount 50% of the time.

    Args:
        price: Original price of the product.

    Returns:
        tuple:
            - final_price: Price after a discount.
            - discount_flag (int): 1 if a discount is applied, otherwise 0.
    """
    # TODO: Implement apply_discount
    pass