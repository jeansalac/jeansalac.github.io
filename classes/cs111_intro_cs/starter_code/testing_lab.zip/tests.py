from remittances import *
import unittest

def multiply(num1, num2):
    return num1 * num2

# Step 1: Fix Failing Tests
class TestExample(unittest.TestCase):

    def test_capitalize(self):
        self.assertEqual('jean'.capitalize(), 'jeans')
        self.assertEqual('salac'.capitalize(), 'salad')

    def test_isAlphaNumeric(self):
        self.assertFalse('CS111'.isalnum())
        self.assertTrue('¯\_(ツ)_/¯'.isalnum())

    def test_multiply(self):
        self.assertEqual(multiply(3,4), 34)
        self.assertRaises(IndexError, multiply, '1', '2')

class TestRemittances(unittest.TestCase):
    # Step 2: Standard Cases
    def test_currency_conversion_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    def test_transfer_fee_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation
    
    def test_hours_need_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    # Step 3: Edge Cases
    def test_currency_conversion_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    def test_transfer_fee_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation
    
    def test_hours_need_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    # Step 4: Integration Tests
    def test_expenses_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    def test_expenses_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation



if __name__ == '__main__':
    unittest.main()