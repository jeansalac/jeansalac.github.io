from remittances import *
import unittest

# Step 1: Fix Failing Tests
class TestStringMethods(unittest.TestCase):

    def test_capitalize(self):
        self.assertEqual('jean'.capitalize(), 'jeans')

    def test_isAlphaNumeric(self):
        self.assertFalse('CS111'.isalnum())
        self.assertTrue('¯\_(ツ)_/¯'.isalnum())

    def test_split(self):
        myString = 'Hello World!'
        self.assertEqual(myString.split(), ['hello', 'world!'])
        self.assertRaises(TypeError, myString.split(), '3')

class TestRemittances(unittest.TestCase):
    # Step 2: Standard Cases
    def test_currency_conversion_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    def test_transfer_fee_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation
    
    def test_hours_need_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    # Step 3: Edge Cases
    def test_currency_conversion_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    def test_transfer_fee_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation
    
    def test_hours_need_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    # Step 4: Integration Tests
    def test_expenses_standard(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation

    def test_expenses_edge(self):
        pass # Delete or comment out this "pass" line once you have an initial implementation



if __name__ == '__main__':
    unittest.main()