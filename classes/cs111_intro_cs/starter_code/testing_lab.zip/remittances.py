# Remittances Functions

def currency_conversion(old_currency, conversion):
    new_currency = old_currency * conversion
    return new_currency

def add_transfer_fee(old_currency, conversion, transfer_fee):
    amount_to_convert = old_currency - transfer_fee
    new_currency = amount_to_convert * conversion
    return new_currency

def get_hours(abroad_currency, conversion_abroad_local, transfer_fee, hourly_wage):
    earnings_needed = abroad_currency * conversion_abroad_local + transfer_fee
    hours_needed = earnings_needed/hourly_wage
    return hours_needed
    
def get_hours_with_expenses(abroad_currency, conversion_abroad_local, transfer_fee, hourly_wage, expenses):
    earnings_needed = currency_conversion(abroad_currency, conversion_abroad_local) + transfer_fee
    earnings_needed = earnings_needed + expenses
    hours_needed = earnings_needed/hourly_wage
    return hours_needed