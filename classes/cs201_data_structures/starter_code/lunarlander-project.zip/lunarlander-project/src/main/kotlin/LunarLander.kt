class LunarLander
{

}



fun main()
{

}
