fun main() {
    var myMaze = SolvableMaze("src/main/resources/maze.txt")
    myMaze.solveMaze()
    myMaze.printMaze()
}
