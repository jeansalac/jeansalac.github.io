class SolvableMaze(filename: String) : Maze(filename) {

    // returns true if there is a solution, false otherwise
    fun solveMaze(): Boolean {
        return false
    }
}
